from flask import Flask, render_template, request
## Importamos la librería flask_mysqldb
# Con ello pemrmitirá conectar con la DB
from flask_mysqldb import MySQL

app = Flask(__name__)
mysql = MySQL(app)

###
# Datos de acceso a la Base de Datos
app.config['MYSQL_HOST']='localhost'
app.config['MYSQL_USER']='agencia_user'
app.config['MYSQL_PASSWORD']='666'
app.config['MYSQL_DB']='Agencia'

print("Conexión exitosa")

## Creando ruta
@app.route('/')
def inicio():
    return render_template('index.html')

@app.route('/login',methods=['GET','POST'])
def login():
    mensaje = None
    if request.method == 'POST':
        email = request.form['email']
        contrasenia = request.form['contrasenia']

        ## Vamos a llamar a los Stored Procedure
        cursor = mysql.connection.cursor()
        cursor.callproc('verificar_login',(email,contrasenia, 0))
        resultado = cursor.fetchone()[0]

        if resultado == 1:
            return redirect('bienvenida')
        else:
            mensaje = 'Credenciales inválidas, intente de nuevo'


#### Lectura
## Acceder a la base de datos y mostrar registros
@app.route('/ver', methods=['GET'])
def ver_datos():
    cursor = mysql.connection.cursor()
    # Ejecutamos la sentencia SQL para obtener todo
    cursor.execute('''SELECT id,Nombre, Modelo,Precio FROM Autos''')
    # Almacenamos todo lo necesario en nuestra variable Autos, a través del método fetchall()
    Autos = cursor.fetchall()
    
    # Enviaremos los datos hacia el pagina.html donde Jinja2 los recepcionará
    return render_template('pagina.html', Autos=Autos)

#### Insert de datos
@app.route('/insertar', methods=['GET'])
def insertar():
    return render_template('insertar.html')

@app.route('/insert', methods=['GET','POST'])
def insert():
    if request.method == 'GET':
        return "M&eacute;todo err&oacute;neo, favor de usar el correcto"
    if request.method == 'POST':
        nombre = request.form['nombre']
        precio = request.form['pre']
        modelo = request.form['m']
        cursor = mysql.connection.cursor()
        cursor.execute(''' INSERT INTO Autos (Nombre, Modelo, Precio) VALUES (%s,%s,%s) ''',(nombre, modelo, precio))
        mysql.connection.commit()
        cursor.close()
        return ver_datos()

#### Borrado de datos
@app.route('/borrar/<string:id>')
def borrar(id):
    cursor = mysql.connection.cursor()
    cursor.execute(''' DELETE FROM Autos WHERE id=%s ''', (id,))
    mysql.connection.commit()
    cursor.close()
    return ver_datos()

#### Actualización de datos
@app.route('/editar/<string:id>')
def editar(id):
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT id, Nombre, Modelo, Anio, Precio FROM Autos WHERE id = %s",(id,))
    autos = cursor.fetchall()
    print(autos)
    return render_template('forma_update.html', autos=autos[0])

@app.route('/actualizar/<string:id>', methods=['GET','POST'])
def actualizar(id):
    if request.method == 'GET':
        return "M&eacute;todo err&oacute;neo, favor de usar el correcto"
    if request.method == 'POST':
        nombre = request.form['nombre']
        precio = request.form['pre']
        modelo = request.form['m']
        anio = request.form['anio']
        cursor = mysql.connection.cursor()
        cursor.execute(" UPDATE Autos SET Nombre=%s, Modelo=%s, Anio=%s, Precio=%s WHERE id = %s",(nombre, modelo, anio, precio, id))
        mysql.connection.commit()
        cursor.close()
        return ver_datos()

#### DROPDOWN MENU

@app.route('/selecciona')
def selecciona():
    cursor = mysql.connection.cursor()
    cursor.execute(''' SELECT * FROM Categorias  ''')
    categorias = cursor.fetchall()
    cursor.close()
    return render_template('selecciona.html', categorias=categorias)

@app.route('/productos/')
def productos():
    id = request.args.get("categoria")
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT * FROM Productos WHERE categoria_id = %s ", [id])
    productos = cursor.fetchall()
    cursor.close()
    return render_template('productos.html', productos=productos)


@app.route('/buscar')
def buscar():
    return render_template('buscar.html')

@app.route('/autocomplete', methods=['POST'])
def autocomplete():
    input = request.form['input']
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT Nombre FROM Productos WHERE Nombre LIKE %s",('%' + input + '%',))
    resultado = cursor.fetchall()
    cursor.close()
    return render_template("autocomplete.html", resultado=resultado)


if __name__ == '__main__':
    app.run(debug=True)
