USE Tienda;

DELIMITER //
CREATE PROCEDURE registroUsuario(
    IN nombre VARCHAR(50),
    IN appaterno VARCHAR(50),
    IN apmaterno VARCHAR(50),
    IN correo VARCHAR(100),
    IN pass VARCHAR(100)
)
BEGIN
    DECLARE usuario_id INT;

    -- Verificamos si el usuario existe
    IF (SELECT EXISTS (SELECT 1 FROM Login WHERE email = correo)) THEN
        SELECT 'Este usuario ya existe!';
    ELSE
        INSERT INTO Usuarios (nombre,apaterno,amaterno)
        VALUES (nombre,appaterno,apmaterno);
    
    -- Obtenemos el Id del Usuario insertado
    SET usuario_id = LAST_INSERT_ID();

    -- Ahora Insertamos los datos en la tabla Login
    INSERT INTO Login (usuario_id, contrasenia, email)
    VALUES (usuario_id, pass, correo);

    SELECT 'Registro exitoso' AS mensaje;
    END IF;
END //
DELIMITER ;