-- MariaDB dump 10.19  Distrib 10.5.16-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: Agencia
-- ------------------------------------------------------
-- Server version	10.5.16-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `Autos`
--

LOCK TABLES `Autos` WRITE;
/*!40000 ALTER TABLE `Autos` DISABLE KEYS */;
INSERT INTO `Autos` VALUES (1,'Honda','Accord',2023,900003),(2,'Toyota','Camry',2023,750000),(4,'Kia','Forte',2024,390000),(5,'Audi','TT',2023,1800000);
/*!40000 ALTER TABLE `Autos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `Categorias`
--

LOCK TABLES `Categorias` WRITE;
/*!40000 ALTER TABLE `Categorias` DISABLE KEYS */;
INSERT INTO `Categorias` VALUES (1,'Electricos'),(2,'Gasolina'),(3,'Diesel'),(4,'Hidrogeno');
/*!40000 ALTER TABLE `Categorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `Productos`
--

LOCK TABLES `Productos` WRITE;
/*!40000 ALTER TABLE `Productos` DISABLE KEYS */;
INSERT INTO `Productos` VALUES (1,'Prius',NULL,600000,'https://img.remediosdigitales.com/c467e9/ferrari-sf90-spider-el-auto-mas-caro-de-mexico7/840_560.jpeg',1),(2,'Model S','Electric car',800000,'https://upload.wikimedia.org/wikipedia/commons/thumb/1/14/2018_Tesla_Model_S_75D.jpg/450px-2018_Tesla_Model_S_75D.jpg',1),(3,'Civic','Gasoline car',50000,'https://dealer-communications.com/wp-content/uploads/2012/10/06_2012_Civic_Natural_Gas.jpg',2),(4,'F-150','Diesel truck',70000,'https://www.elcarrocolombiano.com/wp-content/uploads/2021/07/202114-FORD-F-150-DIESEL-ADIOS-PORTADA.jpg',3),(5,'Mirai','Hydrogen car',750000,'https://s7d2.scene7.com/is/image/TWCNews/2021toyotamirai_jpeg',4),(6,'Corvette','Gasoline sports car',90000,'https://s1.cdn.autoevolution.com/images/news/european-c8-corvette-loses-almost-30-hp-over-gasoline-particulate-filter-159911_1.jpg',2);
/*!40000 ALTER TABLE `Productos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-22 21:25:57
