CREATE DATABASE Tiendita;

USE Tiendita;

CREATE TABLE customers(
    cid int not null,
    c_name VARCHAR(50),
    c_state CHAR(3),
    PRIMARY KEY (cid)
);

CREATE TABLE products(
    pid int not null auto_increment,
    p_desc VARCHAR(50),
    p_price DECIMAL(10,2),
    PRIMARY KEY (pid)
);

CREATE TABLE orders(
    oid int not null auto_increment,
    o_date date not null,
    cid int not null,
    PRIMARY KEY (oid),
    FOREIGN KEY (cid) REFERENCES customers (cid)
);

CREATE TABLE orders_details(
    oid int not null,
    pid int not null,
    qty int not null,
    PRIMARY KEY (oid),
    FOREIGN KEY (pid) REFERENCES products (pid)
);