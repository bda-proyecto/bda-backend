USE Agencia;

DELIMITER $$
CREATE PROCEDURE verificar_login(
    IN correo VARCHAR(100),
    IN password VARCHAR(100),
    OUT resultado INT
)
BEGIN
    SELECT COUNT(*) INTO resultado FROM Login WHERE (email=correo AND contrasenia=password);
END $$
DELIMITER ;

