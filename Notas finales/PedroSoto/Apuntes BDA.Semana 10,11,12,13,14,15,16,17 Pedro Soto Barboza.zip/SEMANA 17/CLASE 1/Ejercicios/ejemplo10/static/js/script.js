$(document).ready(function(){
  $('#login-form').submit(function(event){
        event.preventDefault();
        $.ajax(
                {
                        url:'/login',
                        method: 'POST',
                        data: $(this).serialize(),
                        success: function(response) {
                                window.location.href = response;
                        },
                        error: function(xhr){
                                $('#mensaje').text('Credenciales invalidas')
                        }
                }
        )
  })
});
