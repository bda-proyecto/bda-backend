------------------------    LOGIN ---------------------------------------------------------------------
DELIMITER //
CREATE PROCEDURE verificar_login (
    IN correo VARCHAR(255), 
    IN pass VARCHAR(255)
)
BEGIN
    DECLARE resultado BOOLEAN;
    
    -- Utilizamos LIMIT 1 para asegurarnos de obtener solo una fila
    SELECT COUNT(*) INTO resultado
    FROM Login
    WHERE (email = correo AND contrasenia = pass)
    LIMIT 1;

    -- Si no se encuentra el usuario, establecer el resultado a 0
    IF resultado IS NULL THEN
        SET resultado = 0;
    END IF;

    -- Agregamos esto para regresar el resultado
    SELECT resultado AS resultado;
END //
DELIMITER ;

CALL verificar_login('elpapi@elguapo.com', '666');
--------------------- REGISTRO -------------------------------------------------------- -------------
DELIMITER //
CREATE PROCEDURE registroUsuario(
   IN nombre varchar(50),
   IN apaterno varchar(50),
   IN apmaterno varchar(50),
   IN correo varchar(100),
   IN pass varchar(100)
)
BEGIN
  DECLARE usuario_id INT;

    -- Verificamos si el usuario ya existe
    IF (SELECT COUNT(*) FROM Login WHERE email =  correo) > 0 THEN
        SELECT 'Este usuario ya existe!' AS mensaje;
    ELSE
        -- Insertamos los datos del nuevo usuario en la tabla Usuarios
        INSERT INTO Usuarios (nombre,apaterno, amaterno)
        VALUES (nombre,apaterno,apmaterno);

        -- Obtenemos el id del usuario insertado
        SET usuario_id = LAST_INSERT_ID();

        -- Ahora insertamos los datos en la tabla Login
        INSERT INTO Login (usuario_id, contrasenia, email)
        VALUES (usuario_id,pass,correo);

        SELECT 'Registro exitoso' AS mensaje;
    END IF;
END //
DELIMITER ;

------------------

CALL registroUsuario('Peje','Lagarto','Rosado','peje@elpeje.com','1234');
