USE Agencia;

CREATE TABLE Categorias(
    id int not null auto_increment primary key,
    nombre varchar(100)
);

CREATE TABLE Productos(
    id int not null auto_increment primary key,
    nombre varchar(50),
    descripcion varchar(100),
    precio int(30),
    imagen varchar(255),
    categoria_id int not null,
    FOREIGN KEY (categoria_id) REFERENCES Categorias(id)
);

INSERT INTO Categorias (Nombre) VALUES ('Electricos'),('Gasolina'),('Diesel'),('Hidrogeno');

INSERT INTO Productos (nombre, precio, imagen, categoria_id) VALUES ('Prius', 600000, 'https://img.remediosdigitales.com/c467e9/ferrari-sf90-spider-el-auto-mas-caro-de-mexico7/840_560.jpeg', 1);

