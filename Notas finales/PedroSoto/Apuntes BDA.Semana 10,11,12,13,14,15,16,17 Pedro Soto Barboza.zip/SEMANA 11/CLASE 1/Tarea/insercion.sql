
USE Agencia;


INSERT INTO Productos (nombre, descripcion, precio, imagen, categoria_id) VALUES 
('Model S', 'Electric car', 800000, 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/14/2018_Tesla_Model_S_75D.jpg/450px-2018_Tesla_Model_S_75D.jpg', 1),
('Civic', 'Gasoline car', 50000, 'https://dealer-communications.com/wp-content/uploads/2012/10/06_2012_Civic_Natural_Gas.jpg', 2),
('F-150', 'Diesel truck', 70000, 'https://www.elcarrocolombiano.com/wp-content/uploads/2021/07/202114-FORD-F-150-DIESEL-ADIOS-PORTADA.jpg', 3),
('Mirai', 'Hydrogen car', 750000, 'https://s7d2.scene7.com/is/image/TWCNews/2021toyotamirai_jpeg', 4),
('Corvette', 'Gasoline sports car', 90000, 'https://s1.cdn.autoevolution.com/images/news/european-c8-corvette-loses-almost-30-hp-over-gasoline-particulate-filter-159911_1.jpg', 2);