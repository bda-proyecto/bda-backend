$(document).ready(function(){
  $('#input').keyup(function(){
    $.ajax({
	type: 'POST',
	url: '/autocomplete',
	data: {
	   input: $('#input').val()
	},
	success: function(data){
	   $('#resultado').html(data);
	}
    });
  });
});
