USE Agencia;


INSERT INTO Categorias (Nombre) VALUES ('Hibrido');


ALTER TABLE Productos MODIFY Imagen varchar(500);


INSERT INTO Productos (nombre, descripcion, categoria_id) VALUES ('Honda', 'Accord', 5), ('Toyota','Camry', 5), ('Ford', 'Focus', 2), ('Kia','Forte',2);


UPDATE Productos SET Precio = 900000, Imagen = 'https://img.remediosdigitales.com/1dd87c/honda-accord-2018-mexico_/840_560.jpg' WHERE id = 1;
