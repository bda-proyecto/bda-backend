CREATE DATABASE Compras;

GRANT ALL PRIVILEGES ON Compras.* TO usr_compras@localhost IDENTIFIED BY '123'

FLUSH PRIVILEGES;

USE Compras;

CREATE TABLE estados(
    id_estado INT NOT NULL AUTO_INCREMENT,
    estado VARCHAR(50),
    PRIMARY KEY (id_estado)
);

CREATE TABLE clientes(
    id_cliente INT NOT NULL AUTO_INCREMENT,
    nom_cliente VARCHAR(50),
    id_estado INT NOT NULL,
    PRIMARY KEY (id_cliente),
    FOREIGN KEY (id_estado) REFERENCES estados (id_estado)
);

CREATE TABLE ordenes (
  id_orden INT NOT NULL AUTO_INCREMENT,
  fecha DATE,
  id_cliente INT NOT NULL,
  PRIMARY KEY (id_orden),
  FOREIGN KEY (id_cliente) REFERENCES clientes (id_cliente)
);

CREATE TABLE articulos(
    num_item INT NOT NULL AUTO_INCREMENT,
    desc_item VARCHAR(100),
    precio DOUBLE(10,2),
    PRIMARY KEY (num_item)
);

CREATE TABLE articulos_ordenes(
    id_orden INT NOT NULL,
    num_item INT NOT NULL,
    cant INT,
    PRIMARY KEY (id_orden, num_item),
    FOREIGN KEY (id_orden) REFERENCES ordenes (id_orden),
    FOREIGN KEY (num_item) REFERENCES articulos (num_item)
);

