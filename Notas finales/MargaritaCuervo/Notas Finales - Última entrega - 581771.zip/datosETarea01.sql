-- MariaDB dump 10.19  Distrib 10.5.16-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: ETarea01
-- ------------------------------------------------------
-- Server version	10.5.16-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `Categorias`
--

LOCK TABLES `Categorias` WRITE;
/*!40000 ALTER TABLE `Categorias` DISABLE KEYS */;
INSERT INTO `Categorias` VALUES (1,'electrónica'),(2,'juguetes'),(3,'muebles'),(4,'ropa');
/*!40000 ALTER TABLE `Categorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `Clientes`
--

LOCK TABLES `Clientes` WRITE;
/*!40000 ALTER TABLE `Clientes` DISABLE KEYS */;
INSERT INTO `Clientes` VALUES (1,'Ana Pérez','Calle 123 Cuidad A',555123567),(2,'Luis Gómez','Avenida Principal Cuidad B',555215376),(3,'Carlos Vargas','Avenida Sur Cuidad C',555678901),(4,'Laura Morales','Calle 456 Cuidad B',555234567);
/*!40000 ALTER TABLE `Clientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `Detalles_Pedidos`
--

LOCK TABLES `Detalles_Pedidos` WRITE;
/*!40000 ALTER TABLE `Detalles_Pedidos` DISABLE KEYS */;
INSERT INTO `Detalles_Pedidos` VALUES (1,1,1),(2,1,2),(3,4,2),(4,5,10),(5,2,5),(6,3,2);
/*!40000 ALTER TABLE `Detalles_Pedidos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `Pedidos`
--

LOCK TABLES `Pedidos` WRITE;
/*!40000 ALTER TABLE `Pedidos` DISABLE KEYS */;
INSERT INTO `Pedidos` VALUES (1,'2023-10-31',1,1),(2,'2023-10-31',2,2),(3,'2023-11-01',2,3),(4,'2023-11-01',4,4),(5,'2023-11-02',1,5),(6,'2023-11-03',3,6);
/*!40000 ALTER TABLE `Pedidos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `Productos`
--

LOCK TABLES `Productos` WRITE;
/*!40000 ALTER TABLE `Productos` DISABLE KEYS */;
INSERT INTO `Productos` VALUES (1,'Laptop HP',799,'Laptop HP Core i5 8GB RAM',1),(2,'Rompecabezas 1000 piezas',21,'Rompecabezas desafiante de 1000 piezas',2),(3,'Refrigerador LG',1199,'Refrigerador LG InstaView eficiente',3),(4,'Roomba 960',499,'Aspiradora robot Roomba 960 con mapeo',3),(5,'Camiseta',20,'Camisa de algodón para hombres',4);
/*!40000 ALTER TABLE `Productos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-03 15:18:34
