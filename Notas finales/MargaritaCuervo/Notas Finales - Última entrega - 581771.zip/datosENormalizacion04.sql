-- MariaDB dump 10.19  Distrib 10.5.16-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: Tienda
-- ------------------------------------------------------
-- Server version	10.5.16-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `Carritos`
--

LOCK TABLES `Carritos` WRITE;
/*!40000 ALTER TABLE `Carritos` DISABLE KEYS */;
/*!40000 ALTER TABLE `Carritos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `Categorias`
--

LOCK TABLES `Categorias` WRITE;
/*!40000 ALTER TABLE `Categorias` DISABLE KEYS */;
/*!40000 ALTER TABLE `Categorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `Direcciones`
--

LOCK TABLES `Direcciones` WRITE;
/*!40000 ALTER TABLE `Direcciones` DISABLE KEYS */;
/*!40000 ALTER TABLE `Direcciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `Disponibilidad`
--

LOCK TABLES `Disponibilidad` WRITE;
/*!40000 ALTER TABLE `Disponibilidad` DISABLE KEYS */;
/*!40000 ALTER TABLE `Disponibilidad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `Login`
--

LOCK TABLES `Login` WRITE;
/*!40000 ALTER TABLE `Login` DISABLE KEYS */;
INSERT INTO `Login` VALUES (1,1,'666','admin@udem.edu'),(2,2,'999','raulms'),(3,4,'1234','peje@elpeje.com');
/*!40000 ALTER TABLE `Login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `Metodos_Pago`
--

LOCK TABLES `Metodos_Pago` WRITE;
/*!40000 ALTER TABLE `Metodos_Pago` DISABLE KEYS */;
/*!40000 ALTER TABLE `Metodos_Pago` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `Pagos`
--

LOCK TABLES `Pagos` WRITE;
/*!40000 ALTER TABLE `Pagos` DISABLE KEYS */;
/*!40000 ALTER TABLE `Pagos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `Pedidos`
--

LOCK TABLES `Pedidos` WRITE;
/*!40000 ALTER TABLE `Pedidos` DISABLE KEYS */;
/*!40000 ALTER TABLE `Pedidos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `Precios_producto`
--

LOCK TABLES `Precios_producto` WRITE;
/*!40000 ALTER TABLE `Precios_producto` DISABLE KEYS */;
/*!40000 ALTER TABLE `Precios_producto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `Productos`
--

LOCK TABLES `Productos` WRITE;
/*!40000 ALTER TABLE `Productos` DISABLE KEYS */;
/*!40000 ALTER TABLE `Productos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `Productos_Carritos`
--

LOCK TABLES `Productos_Carritos` WRITE;
/*!40000 ALTER TABLE `Productos_Carritos` DISABLE KEYS */;
/*!40000 ALTER TABLE `Productos_Carritos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `Productos_Categorias`
--

LOCK TABLES `Productos_Categorias` WRITE;
/*!40000 ALTER TABLE `Productos_Categorias` DISABLE KEYS */;
/*!40000 ALTER TABLE `Productos_Categorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `Seguimiento_Pedidos`
--

LOCK TABLES `Seguimiento_Pedidos` WRITE;
/*!40000 ALTER TABLE `Seguimiento_Pedidos` DISABLE KEYS */;
/*!40000 ALTER TABLE `Seguimiento_Pedidos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `Tarjetas`
--

LOCK TABLES `Tarjetas` WRITE;
/*!40000 ALTER TABLE `Tarjetas` DISABLE KEYS */;
/*!40000 ALTER TABLE `Tarjetas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `Transacciones`
--

LOCK TABLES `Transacciones` WRITE;
/*!40000 ALTER TABLE `Transacciones` DISABLE KEYS */;
/*!40000 ALTER TABLE `Transacciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `Usuarios`
--

LOCK TABLES `Usuarios` WRITE;
/*!40000 ALTER TABLE `Usuarios` DISABLE KEYS */;
INSERT INTO `Usuarios` VALUES (1,'Administrador',NULL,NULL),(2,'Raul','Morales','Salcedo'),(4,'Peje','Lagarto','Rosado');
/*!40000 ALTER TABLE `Usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-23  0:09:39
